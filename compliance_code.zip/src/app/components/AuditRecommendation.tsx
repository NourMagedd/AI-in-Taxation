import { useState } from 'react';
import { Target, AlertCircle, CheckCircle2, TrendingDown } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';

interface AuditCase {
  id: string;
  taxpayerId: string;
  name: string;
  riskScore: number;
  priority: number;
  income: number;
  paymentHistory: string;
  recommendedAction: string;
  estimatedRecovery: number;
}

const mockAuditCases: AuditCase[] = [
  {
    id: 'AUD-001',
    taxpayerId: 'TP-10891',
    name: 'Global Imports LLC',
    riskScore: 92,
    priority: 1,
    income: 89000,
    paymentHistory: '3 late payments, 1 missed',
    recommendedAction: 'Full audit - high fraud risk',
    estimatedRecovery: 12500
  },
  {
    id: 'AUD-002',
    taxpayerId: 'TP-10567',
    name: 'Tech Solutions Inc',
    riskScore: 85,
    priority: 2,
    income: 67000,
    paymentHistory: '2 late payments',
    recommendedAction: 'Document review audit',
    estimatedRecovery: 8200
  },
  {
    id: 'AUD-003',
    taxpayerId: 'TP-10023',
    name: 'Retail Partners Co',
    riskScore: 78,
    priority: 3,
    income: 45000,
    paymentHistory: '1 late payment',
    recommendedAction: 'Targeted deduction review',
    estimatedRecovery: 5600
  },
  {
    id: 'AUD-004',
    taxpayerId: 'TP-11789',
    name: 'Finance Advisors',
    riskScore: 71,
    priority: 4,
    income: 112000,
    paymentHistory: 'Consistent but low payments',
    recommendedAction: 'Income verification audit',
    estimatedRecovery: 9800
  },
  {
    id: 'AUD-005',
    taxpayerId: 'TP-10445',
    name: 'Construction Plus',
    riskScore: 68,
    priority: 5,
    income: 98000,
    paymentHistory: '4 late payments',
    recommendedAction: 'Payment compliance review',
    estimatedRecovery: 6400
  },
];

const riskDistribution = [
  { range: '90-100', count: 8, color: '#dc2626' },
  { range: '80-89', count: 15, color: '#ea580c' },
  { range: '70-79', count: 23, color: '#f59e0b' },
  { range: '60-69', count: 18, color: '#eab308' },
  { range: '0-59', count: 42, color: '#22c55e' },
];

export default function AuditRecommendation() {
  const [selectedCase, setSelectedCase] = useState<AuditCase | null>(null);
  const [generating, setGenerating] = useState(false);

  const handleGenerate = () => {
    setGenerating(true);
    setTimeout(() => {
      setGenerating(false);
    }, 2000);
  };

  const totalRecovery = mockAuditCases.reduce((sum, c) => sum + c.estimatedRecovery, 0);
  const avgRiskScore = mockAuditCases.reduce((sum, c) => sum + c.riskScore, 0) / mockAuditCases.length;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl mb-2">Predictive Audit Recommendation</h2>
          <p className="text-gray-600">Gradient Boosting model for risk-based audit prioritization</p>
        </div>
        <button
          onClick={handleGenerate}
          disabled={generating}
          className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 disabled:bg-gray-400"
        >
          {generating ? 'Generating...' : 'Generate New Rankings'}
        </button>
      </div>

      <div className="grid grid-cols-4 gap-4">
        <div className="bg-white p-6 rounded-lg border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">High Priority Cases</p>
              <p className="text-3xl mt-1">{mockAuditCases.length}</p>
            </div>
            <Target className="w-8 h-8 text-blue-500" />
          </div>
        </div>
        <div className="bg-white p-6 rounded-lg border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Avg Risk Score</p>
              <p className="text-3xl mt-1">{avgRiskScore.toFixed(0)}</p>
            </div>
            <AlertCircle className="w-8 h-8 text-orange-500" />
          </div>
        </div>
        <div className="bg-white p-6 rounded-lg border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Est. Recovery</p>
              <p className="text-3xl mt-1">${(totalRecovery / 1000).toFixed(0)}K</p>
            </div>
            <TrendingDown className="w-8 h-8 text-green-500" />
          </div>
        </div>
        <div className="bg-white p-6 rounded-lg border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Model Accuracy</p>
              <p className="text-3xl mt-1">89.7%</p>
            </div>
            <CheckCircle2 className="w-8 h-8 text-green-500" />
          </div>
        </div>
      </div>

      <div className="bg-white p-6 rounded-lg border border-gray-200">
        <h3 className="text-lg mb-4">Risk Score Distribution</h3>
        <ResponsiveContainer width="100%" height={250}>
          <BarChart data={riskDistribution}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="range" />
            <YAxis />
            <Tooltip />
            <Bar dataKey="count">
              {riskDistribution.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={entry.color} />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>

      <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
        <div className="bg-gray-50 px-6 py-3 border-b border-gray-200">
          <h3 className="text-lg">Ranked Audit Cases - High Priority</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="px-6 py-3 text-left text-xs text-gray-600">Priority</th>
                <th className="px-6 py-3 text-left text-xs text-gray-600">Audit ID</th>
                <th className="px-6 py-3 text-left text-xs text-gray-600">Taxpayer Name</th>
                <th className="px-6 py-3 text-left text-xs text-gray-600">Risk Score</th>
                <th className="px-6 py-3 text-left text-xs text-gray-600">Est. Recovery</th>
                <th className="px-6 py-3 text-left text-xs text-gray-600">Recommended Action</th>
                <th className="px-6 py-3 text-left text-xs text-gray-600">Details</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {mockAuditCases.map((auditCase) => (
                <tr key={auditCase.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4">
                    <span className={`inline-flex items-center justify-center w-8 h-8 rounded-full text-sm ${
                      auditCase.priority === 1 ? 'bg-red-100 text-red-800' :
                      auditCase.priority === 2 ? 'bg-orange-100 text-orange-800' :
                      'bg-yellow-100 text-yellow-800'
                    }`}>
                      {auditCase.priority}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-sm">{auditCase.id}</td>
                  <td className="px-6 py-4 text-sm">{auditCase.name}</td>
                  <td className="px-6 py-4">
                    <div className="flex items-center">
                      <span className={`text-sm ${
                        auditCase.riskScore >= 85 ? 'text-red-600' :
                        auditCase.riskScore >= 70 ? 'text-orange-600' :
                        'text-yellow-600'
                      }`}>
                        {auditCase.riskScore}
                      </span>
                      <div className="ml-2 w-16 bg-gray-200 rounded-full h-2">
                        <div
                          className={`h-2 rounded-full ${
                            auditCase.riskScore >= 85 ? 'bg-red-600' :
                            auditCase.riskScore >= 70 ? 'bg-orange-600' :
                            'bg-yellow-600'
                          }`}
                          style={{ width: `${auditCase.riskScore}%` }}
                        />
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-sm">${auditCase.estimatedRecovery.toLocaleString()}</td>
                  <td className="px-6 py-4 text-sm">{auditCase.recommendedAction}</td>
                  <td className="px-6 py-4">
                    <button
                      onClick={() => setSelectedCase(auditCase)}
                      className="px-3 py-1 bg-blue-500 text-white text-sm rounded hover:bg-blue-600"
                    >
                      View
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {selectedCase && (
        <div className="bg-white p-6 rounded-lg border-2 border-blue-200">
          <h3 className="text-lg mb-4">Gradient Boosting Model Analysis - {selectedCase.name}</h3>
          <div className="grid grid-cols-2 gap-6">
            <div>
              <p className="text-sm text-gray-600 mb-2">Model Input Features</p>
              <ul className="space-y-2 text-sm">
                <li>Taxpayer ID: {selectedCase.taxpayerId}</li>
                <li>Annual Income: ${selectedCase.income.toLocaleString()}</li>
                <li>Payment History: {selectedCase.paymentHistory}</li>
                <li>Historical Filings: 12 submissions</li>
                <li>Deduction Patterns: Analyzed</li>
              </ul>
            </div>
            <div>
              <p className="text-sm text-gray-600 mb-2">Model Output & Recommendations</p>
              <ul className="space-y-2 text-sm">
                <li>Risk Score: <strong className="text-red-600">{selectedCase.riskScore}</strong></li>
                <li>Priority Rank: <strong>#{selectedCase.priority}</strong></li>
                <li>Action: <strong>{selectedCase.recommendedAction}</strong></li>
                <li>Estimated Recovery: <strong>${selectedCase.estimatedRecovery.toLocaleString()}</strong></li>
                <li>Model Confidence: <strong>91.2%</strong></li>
              </ul>
            </div>
          </div>
          <div className="mt-4 p-4 bg-blue-50 rounded border border-blue-200">
            <p className="text-sm text-blue-900">
              <strong>AI Recommendation:</strong> This case shows high-risk indicators including payment delinquency and unusual deduction patterns.
              Allocate audit resources to this case within the next 30 days for maximum recovery potential.
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
