import { BarChart, Bar, LineChart, Line, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { TrendingUp, AlertTriangle, CheckCircle, Activity, Database, BookOpen } from 'lucide-react';

const complianceData = [
  { month: 'Jan', compliant: 145, nonCompliant: 23 },
  { month: 'Feb', compliant: 168, nonCompliant: 18 },
  { month: 'Mar', compliant: 192, nonCompliant: 15 },
  { month: 'Apr', compliant: 178, nonCompliant: 28 },
];

const riskDistribution = [
  { name: 'Low Risk', value: 65, color: '#22c55e' },
  { name: 'Medium Risk', value: 25, color: '#f59e0b' },
  { name: 'High Risk', value: 10, color: '#ef4444' },
];

const processingStats = [
  { category: 'Invoices', processed: 234, pending: 45 },
  { category: 'Statements', processed: 156, pending: 23 },
  { category: 'Receipts', processed: 389, pending: 67 },
  { category: 'Contracts', processed: 78, pending: 12 },
];

export default function Dashboard() {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl mb-2">AI Tax Compliance Dashboard</h2>
        <p className="text-gray-600">Comprehensive overview of all AI-powered compliance systems</p>
      </div>

      <div className="grid grid-cols-3 gap-4">
        <div className="bg-gradient-to-br from-blue-500 to-blue-600 text-white p-6 rounded-lg">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg">Total Filings Analyzed</h3>
            <Activity className="w-8 h-8 opacity-80" />
          </div>
          <p className="text-4xl mb-2">1,247</p>
          <p className="text-sm opacity-90">↑ 12% from last month</p>
        </div>

        <div className="bg-gradient-to-br from-green-500 to-green-600 text-white p-6 rounded-lg">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg">Compliance Rate</h3>
            <CheckCircle className="w-8 h-8 opacity-80" />
          </div>
          <p className="text-4xl mb-2">92.4%</p>
          <p className="text-sm opacity-90">↑ 3.2% improvement</p>
        </div>

        <div className="bg-gradient-to-br from-red-500 to-red-600 text-white p-6 rounded-lg">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg">Fraud Cases Detected</h3>
            <AlertTriangle className="w-8 h-8 opacity-80" />
          </div>
          <p className="text-4xl mb-2">47</p>
          <p className="text-sm opacity-90">This quarter</p>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-lg border border-gray-200">
          <h3 className="text-lg mb-4 flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-blue-600" />
            Compliance Trends
          </h3>
          <ResponsiveContainer width="100%" height={250}>
            <LineChart data={complianceData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="month" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="compliant" stroke="#22c55e" strokeWidth={2} name="Compliant" />
              <Line type="monotone" dataKey="nonCompliant" stroke="#ef4444" strokeWidth={2} name="Non-Compliant" />
            </LineChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-white p-6 rounded-lg border border-gray-200">
          <h3 className="text-lg mb-4 flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-orange-600" />
            Risk Distribution
          </h3>
          <ResponsiveContainer width="100%" height={250}>
            <PieChart>
              <Pie
                data={riskDistribution}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                outerRadius={80}
                fill="#8884d8"
                dataKey="value"
              >
                {riskDistribution.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="bg-white p-6 rounded-lg border border-gray-200">
        <h3 className="text-lg mb-4 flex items-center gap-2">
          <Database className="w-5 h-5 text-purple-600" />
          Document Processing Status
        </h3>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={processingStats}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="category" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Bar dataKey="processed" fill="#22c55e" name="Processed" />
            <Bar dataKey="pending" fill="#f59e0b" name="Pending" />
          </BarChart>
        </ResponsiveContainer>
      </div>

      <div className="grid grid-cols-3 gap-4">
        <div className="bg-white p-6 rounded-lg border border-gray-200">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
              <CheckCircle className="w-6 h-6 text-blue-600" />
            </div>
            <div>
              <p className="text-sm text-gray-600">MLP Classifier</p>
              <p className="text-xl">Active</p>
            </div>
          </div>
          <p className="text-sm text-gray-600">Accuracy: 92.4%</p>
        </div>

        <div className="bg-white p-6 rounded-lg border border-gray-200">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center">
              <AlertTriangle className="w-6 h-6 text-red-600" />
            </div>
            <div>
              <p className="text-sm text-gray-600">ANN Detector</p>
              <p className="text-xl">Active</p>
            </div>
          </div>
          <p className="text-sm text-gray-600">Detection Rate: 94.2%</p>
        </div>

        <div className="bg-white p-6 rounded-lg border border-gray-200">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
              <TrendingUp className="w-6 h-6 text-green-600" />
            </div>
            <div>
              <p className="text-sm text-gray-600">Gradient Boost</p>
              <p className="text-xl">Active</p>
            </div>
          </div>
          <p className="text-sm text-gray-600">Accuracy: 89.7%</p>
        </div>
      </div>

      <div className="bg-gradient-to-r from-blue-50 to-purple-50 p-6 rounded-lg border border-blue-200">
        <div className="flex items-start gap-4">
          <div className="w-12 h-12 bg-blue-500 rounded-lg flex items-center justify-center flex-shrink-0">
            <BookOpen className="w-6 h-6 text-white" />
          </div>
          <div>
            <h3 className="text-lg mb-2">System Status: All AI Models Operational</h3>
            <p className="text-sm text-gray-700 mb-3">
              All machine learning models are running optimally. The system has processed 1,247 tax filings this month,
              detected 47 potential fraud cases, and maintained a 92.4% compliance classification accuracy.
            </p>
            <div className="grid grid-cols-4 gap-4 text-sm">
              <div>
                <p className="text-gray-600">MLP Model</p>
                <p className="text-green-600">✓ Operational</p>
              </div>
              <div>
                <p className="text-gray-600">ANN Model</p>
                <p className="text-green-600">✓ Operational</p>
              </div>
              <div>
                <p className="text-gray-600">Gradient Boost</p>
                <p className="text-green-600">✓ Operational</p>
              </div>
              <div>
                <p className="text-gray-600">NLP + RAG</p>
                <p className="text-green-600">✓ Operational</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
