import { useState } from 'react';
import { Search, BookOpen, MessageSquare, CheckCircle, Info } from 'lucide-react';

interface Regulation {
  id: string;
  title: string;
  section: string;
  content: string;
  relevance: number;
}

interface PastCase {
  id: string;
  description: string;
  outcome: string;
  similarity: number;
  year: number;
}

const mockRegulations: Regulation[] = [
  {
    id: 'REG-001',
    title: 'Deduction Limits for Business Expenses',
    section: 'Section 162(a)',
    content: 'Ordinary and necessary business expenses are deductible, but must be directly related to business operations and reasonable in amount.',
    relevance: 0.95
  },
  {
    id: 'REG-002',
    title: 'Documentation Requirements for Deductions',
    section: 'Section 274(d)',
    content: 'Taxpayers must maintain adequate records to substantiate deductions, including receipts, invoices, and business purpose documentation.',
    relevance: 0.89
  },
  {
    id: 'REG-003',
    title: 'Home Office Deduction Guidelines',
    section: 'Section 280A',
    content: 'Home office expenses are deductible only if the space is used exclusively and regularly for business purposes.',
    relevance: 0.76
  },
];

const mockCases: PastCase[] = [
  {
    id: 'CASE-2023-045',
    description: 'Business claimed 62% deductions with limited documentation',
    outcome: 'Disallowed - insufficient substantiation',
    similarity: 0.91,
    year: 2023
  },
  {
    id: 'CASE-2022-189',
    description: 'Company with high travel expenses and irregular filings',
    outcome: 'Partially allowed after audit review',
    similarity: 0.84,
    year: 2022
  },
  {
    id: 'CASE-2023-112',
    description: 'Similar income/deduction ratio pattern',
    outcome: 'Full audit conducted, penalties assessed',
    similarity: 0.78,
    year: 2023
  },
];

export default function KnowledgeSupport() {
  const [query, setQuery] = useState('');
  const [searching, setSearching] = useState(false);
  const [results, setResults] = useState<{ regulations: Regulation[], cases: PastCase[] } | null>(null);

  const handleSearch = () => {
    if (!query.trim()) return;

    setSearching(true);
    setTimeout(() => {
      setResults({
        regulations: mockRegulations,
        cases: mockCases
      });
      setSearching(false);
    }, 1500);
  };

  const sampleQueries = [
    'What are the deduction limits for business expenses?',
    'How to handle cases with high deduction ratios?',
    'Documentation requirements for tax filings',
    'Similar cases with payment delinquency'
  ];

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl mb-2">AI-Powered Knowledge Support</h2>
        <p className="text-gray-600">NLP + RAG system for intelligent tax regulation retrieval and case matching</p>
      </div>

      <div className="bg-white p-6 rounded-lg border border-gray-200">
        <div className="flex gap-3">
          <div className="flex-1">
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
              placeholder="Ask about tax regulations, similar cases, or filing requirements..."
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <button
            onClick={handleSearch}
            disabled={searching || !query.trim()}
            className="px-6 py-3 bg-blue-500 text-white rounded-lg hover:bg-blue-600 disabled:bg-gray-400 flex items-center gap-2"
          >
            <Search className="w-4 h-4" />
            {searching ? 'Searching...' : 'Search'}
          </button>
        </div>

        <div className="mt-4">
          <p className="text-sm text-gray-600 mb-2">Sample queries:</p>
          <div className="flex flex-wrap gap-2">
            {sampleQueries.map((sample, idx) => (
              <button
                key={idx}
                onClick={() => setQuery(sample)}
                className="px-3 py-1 bg-gray-100 text-gray-700 text-sm rounded-full hover:bg-gray-200"
              >
                {sample}
              </button>
            ))}
          </div>
        </div>
      </div>

      {results && (
        <>
          <div className="bg-white p-6 rounded-lg border border-gray-200">
            <div className="flex items-center gap-2 mb-4">
              <BookOpen className="w-5 h-5 text-blue-600" />
              <h3 className="text-lg">Relevant Tax Regulations</h3>
            </div>
            <div className="space-y-4">
              {results.regulations.map((reg) => (
                <div key={reg.id} className="p-4 border border-gray-200 rounded-lg hover:border-blue-300">
                  <div className="flex items-start justify-between mb-2">
                    <div>
                      <h4 className="text-sm mb-1">{reg.title}</h4>
                      <p className="text-xs text-gray-600">{reg.section}</p>
                    </div>
                    <div className="flex items-center gap-1 px-2 py-1 bg-blue-50 rounded text-xs text-blue-700">
                      <CheckCircle className="w-3 h-3" />
                      {(reg.relevance * 100).toFixed(0)}% match
                    </div>
                  </div>
                  <p className="text-sm text-gray-700">{reg.content}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-white p-6 rounded-lg border border-gray-200">
            <div className="flex items-center gap-2 mb-4">
              <MessageSquare className="w-5 h-5 text-purple-600" />
              <h3 className="text-lg">Similar Past Cases</h3>
            </div>
            <div className="space-y-4">
              {results.cases.map((case_) => (
                <div key={case_.id} className="p-4 border border-gray-200 rounded-lg hover:border-purple-300">
                  <div className="flex items-start justify-between mb-2">
                    <div>
                      <h4 className="text-sm mb-1">{case_.id} ({case_.year})</h4>
                      <p className="text-sm text-gray-700 mb-2">{case_.description}</p>
                      <div className="flex items-center gap-2">
                        <span className="text-xs px-2 py-1 bg-green-100 text-green-800 rounded">
                          Outcome: {case_.outcome}
                        </span>
                      </div>
                    </div>
                    <div className="flex items-center gap-1 px-2 py-1 bg-purple-50 rounded text-xs text-purple-700 whitespace-nowrap">
                      <Info className="w-3 h-3" />
                      {(case_.similarity * 100).toFixed(0)}% similar
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-blue-50 p-6 rounded-lg border border-blue-200">
            <h3 className="text-lg mb-3 text-blue-900">AI-Generated Recommendation</h3>
            <p className="text-sm text-blue-900 mb-3">
              Based on the retrieved regulations and similar past cases, here are the key considerations for this filing:
            </p>
            <ul className="space-y-2 text-sm text-blue-900">
              <li className="flex items-start gap-2">
                <CheckCircle className="w-4 h-4 mt-0.5 flex-shrink-0 text-blue-600" />
                <span>Ensure all business expense deductions have proper documentation (receipts, invoices)</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle className="w-4 h-4 mt-0.5 flex-shrink-0 text-blue-600" />
                <span>Verify that deduction-to-income ratio aligns with industry standards</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle className="w-4 h-4 mt-0.5 flex-shrink-0 text-blue-600" />
                <span>Similar cases with high deduction ratios often require additional substantiation during audit</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle className="w-4 h-4 mt-0.5 flex-shrink-0 text-blue-600" />
                <span>Consider requesting supplementary documentation before finalizing the filing</span>
              </li>
            </ul>
          </div>
        </>
      )}

      {!results && (
        <div className="bg-gray-50 p-12 rounded-lg border border-gray-200 text-center">
          <Search className="w-16 h-16 text-gray-400 mx-auto mb-4" />
          <p className="text-gray-600">Enter a query to retrieve relevant tax regulations and similar past cases</p>
          <p className="text-sm text-gray-500 mt-2">Powered by Natural Language Processing and Retrieval-Augmented Generation</p>
        </div>
      )}
    </div>
  );
}
