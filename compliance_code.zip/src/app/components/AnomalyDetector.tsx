import { useState } from 'react';
import { AlertTriangle, Shield, Activity } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line } from 'recharts';

interface TaxpayerData {
  id: string;
  name: string;
  income: number;
  deductions: number;
  filings: number;
  anomalyScore: number;
  riskLevel: 'low' | 'medium' | 'high';
  flaggedPatterns: string[];
}

const mockTaxpayers: TaxpayerData[] = [
  {
    id: 'TP-10891',
    name: 'Global Imports LLC',
    income: 89000,
    deductions: 45000,
    filings: 12,
    anomalyScore: 0.87,
    riskLevel: 'high',
    flaggedPatterns: ['Excessive deductions (>50% of income)', 'Irregular filing pattern', 'Multiple late payments']
  },
  {
    id: 'TP-10567',
    name: 'Tech Solutions Inc',
    income: 67000,
    deductions: 32000,
    filings: 8,
    anomalyScore: 0.72,
    riskLevel: 'high',
    flaggedPatterns: ['Sudden deduction spike', 'Inconsistent income reporting']
  },
  {
    id: 'TP-10023',
    name: 'Retail Partners Co',
    income: 45000,
    deductions: 28000,
    filings: 15,
    anomalyScore: 0.58,
    riskLevel: 'medium',
    flaggedPatterns: ['Deduction-to-income ratio above threshold']
  },
  {
    id: 'TP-10234',
    name: 'Manufacturing Pro',
    income: 125000,
    deductions: 15000,
    filings: 24,
    anomalyScore: 0.15,
    riskLevel: 'low',
    flaggedPatterns: []
  },
  {
    id: 'TP-11456',
    name: 'Consulting Group',
    income: 156000,
    deductions: 18000,
    filings: 36,
    anomalyScore: 0.12,
    riskLevel: 'low',
    flaggedPatterns: []
  },
];

const activityData = [
  { month: 'Jan', anomalies: 12, cases: 45 },
  { month: 'Feb', anomalies: 18, cases: 52 },
  { month: 'Mar', anomalies: 24, cases: 68 },
  { month: 'Apr', anomalies: 15, cases: 58 },
];

const deductionDistribution = [
  { range: '0-20%', count: 145 },
  { range: '20-40%', count: 89 },
  { range: '40-60%', count: 23 },
  { range: '60%+', count: 8 },
];

export default function AnomalyDetector() {
  const [selectedTaxpayer, setSelectedTaxpayer] = useState<TaxpayerData | null>(null);
  const [scanning, setScanning] = useState(false);

  const handleScan = () => {
    setScanning(true);
    setTimeout(() => {
      setScanning(false);
    }, 2000);
  };

  const highRiskCount = mockTaxpayers.filter(t => t.riskLevel === 'high').length;
  const mediumRiskCount = mockTaxpayers.filter(t => t.riskLevel === 'medium').length;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl mb-2">Real-Time Anomaly Detection</h2>
          <p className="text-gray-600">ANN-powered fraud detection system analyzing taxpayer behavior patterns</p>
        </div>
        <button
          onClick={handleScan}
          disabled={scanning}
          className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 disabled:bg-gray-400"
        >
          {scanning ? 'Scanning...' : 'Run ANN Scan'}
        </button>
      </div>

      <div className="grid grid-cols-3 gap-4">
        <div className="bg-white p-6 rounded-lg border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">High Risk Cases</p>
              <p className="text-3xl mt-1 text-red-600">{highRiskCount}</p>
            </div>
            <AlertTriangle className="w-8 h-8 text-red-500" />
          </div>
        </div>
        <div className="bg-white p-6 rounded-lg border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Medium Risk</p>
              <p className="text-3xl mt-1 text-yellow-600">{mediumRiskCount}</p>
            </div>
            <Activity className="w-8 h-8 text-yellow-500" />
          </div>
        </div>
        <div className="bg-white p-6 rounded-lg border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Detection Rate</p>
              <p className="text-3xl mt-1 text-green-600">94.2%</p>
            </div>
            <Shield className="w-8 h-8 text-green-500" />
          </div>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-lg border border-gray-200">
          <h3 className="text-lg mb-4">Anomaly Trends</h3>
          <ResponsiveContainer width="100%" height={200}>
            <LineChart data={activityData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="month" />
              <YAxis />
              <Tooltip />
              <Line type="monotone" dataKey="anomalies" stroke="#ef4444" strokeWidth={2} />
            </LineChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-white p-6 rounded-lg border border-gray-200">
          <h3 className="text-lg mb-4">Deduction Distribution</h3>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={deductionDistribution}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="range" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="count" fill="#3b82f6" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="px-6 py-3 text-left text-xs text-gray-600">Taxpayer ID</th>
                <th className="px-6 py-3 text-left text-xs text-gray-600">Name</th>
                <th className="px-6 py-3 text-left text-xs text-gray-600">Income</th>
                <th className="px-6 py-3 text-left text-xs text-gray-600">Deductions</th>
                <th className="px-6 py-3 text-left text-xs text-gray-600">Anomaly Score</th>
                <th className="px-6 py-3 text-left text-xs text-gray-600">Risk Level</th>
                <th className="px-6 py-3 text-left text-xs text-gray-600">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {mockTaxpayers.map((taxpayer) => (
                <tr key={taxpayer.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 text-sm">{taxpayer.id}</td>
                  <td className="px-6 py-4 text-sm">{taxpayer.name}</td>
                  <td className="px-6 py-4 text-sm">${taxpayer.income.toLocaleString()}</td>
                  <td className="px-6 py-4 text-sm">${taxpayer.deductions.toLocaleString()}</td>
                  <td className="px-6 py-4 text-sm">{taxpayer.anomalyScore.toFixed(2)}</td>
                  <td className="px-6 py-4">
                    {taxpayer.riskLevel === 'high' && (
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs bg-red-100 text-red-800">
                        High Risk
                      </span>
                    )}
                    {taxpayer.riskLevel === 'medium' && (
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs bg-yellow-100 text-yellow-800">
                        Medium Risk
                      </span>
                    )}
                    {taxpayer.riskLevel === 'low' && (
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs bg-green-100 text-green-800">
                        Low Risk
                      </span>
                    )}
                  </td>
                  <td className="px-6 py-4">
                    <button
                      onClick={() => setSelectedTaxpayer(taxpayer)}
                      className="px-3 py-1 bg-blue-500 text-white text-sm rounded hover:bg-blue-600"
                    >
                      Analyze
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {selectedTaxpayer && (
        <div className="bg-white p-6 rounded-lg border-2 border-blue-200">
          <h3 className="text-lg mb-4">ANN Analysis - {selectedTaxpayer.name}</h3>
          <div className="grid grid-cols-2 gap-6">
            <div>
              <p className="text-sm text-gray-600 mb-2">Behavioral Metrics</p>
              <ul className="space-y-2 text-sm">
                <li>Income Pattern: ${selectedTaxpayer.income.toLocaleString()}</li>
                <li>Deduction Pattern: ${selectedTaxpayer.deductions.toLocaleString()}</li>
                <li>Deduction Ratio: {((selectedTaxpayer.deductions / selectedTaxpayer.income) * 100).toFixed(1)}%</li>
                <li>Filing Frequency: {selectedTaxpayer.filings} filings</li>
                <li>Anomaly Score: {selectedTaxpayer.anomalyScore.toFixed(2)}</li>
              </ul>
            </div>
            <div>
              <p className="text-sm text-gray-600 mb-2">Flagged Patterns</p>
              {selectedTaxpayer.flaggedPatterns.length > 0 ? (
                <ul className="space-y-2 text-sm">
                  {selectedTaxpayer.flaggedPatterns.map((pattern, idx) => (
                    <li key={idx} className="flex items-start">
                      <AlertTriangle className="w-4 h-4 text-red-500 mr-2 mt-0.5 flex-shrink-0" />
                      <span>{pattern}</span>
                    </li>
                  ))}
                </ul>
              ) : (
                <p className="text-sm text-green-600">No suspicious patterns detected</p>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
