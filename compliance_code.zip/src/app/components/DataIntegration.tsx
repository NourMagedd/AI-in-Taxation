import { useState } from 'react';
import { FileText, Upload, CheckCircle, Clock, AlertCircle, Database } from 'lucide-react';

interface Document {
  id: string;
  name: string;
  type: 'invoice' | 'statement' | 'receipt' | 'contract';
  status: 'pending' | 'processing' | 'extracted' | 'error';
  uploadDate: string;
  extractedData?: {
    amount?: number;
    date?: string;
    vendor?: string;
    category?: string;
  };
}

const mockDocuments: Document[] = [
  {
    id: 'DOC-001',
    name: 'Q1_Invoice_2024.pdf',
    type: 'invoice',
    status: 'extracted',
    uploadDate: '2024-03-15',
    extractedData: {
      amount: 15600,
      date: '2024-01-15',
      vendor: 'Office Supplies Co',
      category: 'Operating Expenses'
    }
  },
  {
    id: 'DOC-002',
    name: 'Financial_Statement_March.pdf',
    type: 'statement',
    status: 'extracted',
    uploadDate: '2024-03-20',
    extractedData: {
      amount: 125000,
      date: '2024-03-01',
      category: 'Revenue'
    }
  },
  {
    id: 'DOC-003',
    name: 'Equipment_Receipt.pdf',
    type: 'receipt',
    status: 'processing',
    uploadDate: '2024-03-22'
  },
  {
    id: 'DOC-004',
    name: 'Service_Contract_2024.pdf',
    type: 'contract',
    status: 'pending',
    uploadDate: '2024-03-25'
  },
];

export default function DataIntegration() {
  const [documents, setDocuments] = useState(mockDocuments);
  const [selectedDoc, setSelectedDoc] = useState<Document | null>(null);
  const [processing, setProcessing] = useState(false);

  const handleProcess = (doc: Document) => {
    setProcessing(true);
    setDocuments(docs => docs.map(d =>
      d.id === doc.id ? { ...d, status: 'processing' } : d
    ));

    setTimeout(() => {
      const extractedData = {
        amount: Math.floor(Math.random() * 50000) + 5000,
        date: new Date().toISOString().split('T')[0],
        vendor: ['Tech Solutions', 'Office Depot', 'Global Supplies'][Math.floor(Math.random() * 3)],
        category: ['Operating Expenses', 'Capital Expenditure', 'Services'][Math.floor(Math.random() * 3)]
      };

      setDocuments(docs => docs.map(d =>
        d.id === doc.id ? { ...d, status: 'extracted', extractedData } : d
      ));
      setProcessing(false);
    }, 3000);
  };

  const stats = {
    total: documents.length,
    processed: documents.filter(d => d.status === 'extracted').length,
    processing: documents.filter(d => d.status === 'processing').length,
    pending: documents.filter(d => d.status === 'pending').length,
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl mb-2">Intelligent Data Integration & Processing</h2>
        <p className="text-gray-600">RPA + NLP system for automated document extraction and standardization</p>
      </div>

      <div className="grid grid-cols-4 gap-4">
        <div className="bg-white p-6 rounded-lg border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Total Documents</p>
              <p className="text-3xl mt-1">{stats.total}</p>
            </div>
            <FileText className="w-8 h-8 text-blue-500" />
          </div>
        </div>
        <div className="bg-white p-6 rounded-lg border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Processed</p>
              <p className="text-3xl mt-1">{stats.processed}</p>
            </div>
            <CheckCircle className="w-8 h-8 text-green-500" />
          </div>
        </div>
        <div className="bg-white p-6 rounded-lg border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Processing</p>
              <p className="text-3xl mt-1">{stats.processing}</p>
            </div>
            <Clock className="w-8 h-8 text-yellow-500" />
          </div>
        </div>
        <div className="bg-white p-6 rounded-lg border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Pending</p>
              <p className="text-3xl mt-1">{stats.pending}</p>
            </div>
            <Upload className="w-8 h-8 text-gray-500" />
          </div>
        </div>
      </div>

      <div className="bg-white p-6 rounded-lg border border-gray-200">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg">Processing Pipeline</h3>
          <button className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 flex items-center gap-2">
            <Upload className="w-4 h-4" />
            Upload Documents
          </button>
        </div>
        <div className="flex items-center justify-between p-4 bg-gray-50 rounded">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
              <Upload className="w-6 h-6 text-blue-600" />
            </div>
            <div>
              <p className="text-sm">Step 1: RPA Upload</p>
              <p className="text-xs text-gray-600">Automated document ingestion</p>
            </div>
          </div>
          <div className="text-gray-400">→</div>
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
              <FileText className="w-6 h-6 text-purple-600" />
            </div>
            <div>
              <p className="text-sm">Step 2: NLP Extraction</p>
              <p className="text-xs text-gray-600">Text and data parsing</p>
            </div>
          </div>
          <div className="text-gray-400">→</div>
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
              <Database className="w-6 h-6 text-green-600" />
            </div>
            <div>
              <p className="text-sm">Step 3: Standardization</p>
              <p className="text-xs text-gray-600">ML-ready data formatting</p>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="px-6 py-3 text-left text-xs text-gray-600">Document ID</th>
                <th className="px-6 py-3 text-left text-xs text-gray-600">Name</th>
                <th className="px-6 py-3 text-left text-xs text-gray-600">Type</th>
                <th className="px-6 py-3 text-left text-xs text-gray-600">Upload Date</th>
                <th className="px-6 py-3 text-left text-xs text-gray-600">Status</th>
                <th className="px-6 py-3 text-left text-xs text-gray-600">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {documents.map((doc) => (
                <tr key={doc.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 text-sm">{doc.id}</td>
                  <td className="px-6 py-4 text-sm">{doc.name}</td>
                  <td className="px-6 py-4">
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs bg-blue-100 text-blue-800 capitalize">
                      {doc.type}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-sm">{doc.uploadDate}</td>
                  <td className="px-6 py-4">
                    {doc.status === 'extracted' && (
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs bg-green-100 text-green-800">
                        <CheckCircle className="w-3 h-3 mr-1" />
                        Extracted
                      </span>
                    )}
                    {doc.status === 'processing' && (
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs bg-yellow-100 text-yellow-800">
                        <Clock className="w-3 h-3 mr-1" />
                        Processing
                      </span>
                    )}
                    {doc.status === 'pending' && (
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs bg-gray-100 text-gray-800">
                        <AlertCircle className="w-3 h-3 mr-1" />
                        Pending
                      </span>
                    )}
                    {doc.status === 'error' && (
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs bg-red-100 text-red-800">
                        <AlertCircle className="w-3 h-3 mr-1" />
                        Error
                      </span>
                    )}
                  </td>
                  <td className="px-6 py-4">
                    {doc.status === 'pending' && (
                      <button
                        onClick={() => handleProcess(doc)}
                        disabled={processing}
                        className="px-3 py-1 bg-blue-500 text-white text-sm rounded hover:bg-blue-600 disabled:bg-gray-400"
                      >
                        Process
                      </button>
                    )}
                    {doc.status === 'extracted' && (
                      <button
                        onClick={() => setSelectedDoc(doc)}
                        className="px-3 py-1 bg-green-500 text-white text-sm rounded hover:bg-green-600"
                      >
                        View Data
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {selectedDoc && selectedDoc.extractedData && (
        <div className="bg-white p-6 rounded-lg border-2 border-green-200">
          <h3 className="text-lg mb-4">Extracted Data - {selectedDoc.name}</h3>
          <div className="grid grid-cols-2 gap-6">
            <div>
              <p className="text-sm text-gray-600 mb-2">NLP Extraction Results</p>
              <ul className="space-y-2 text-sm">
                <li>Amount: <strong>${selectedDoc.extractedData.amount?.toLocaleString()}</strong></li>
                <li>Date: <strong>{selectedDoc.extractedData.date}</strong></li>
                <li>Vendor: <strong>{selectedDoc.extractedData.vendor || 'N/A'}</strong></li>
                <li>Category: <strong>{selectedDoc.extractedData.category}</strong></li>
              </ul>
            </div>
            <div>
              <p className="text-sm text-gray-600 mb-2">Processing Details</p>
              <ul className="space-y-2 text-sm">
                <li>Extraction Method: NLP + OCR</li>
                <li>Confidence: 94.7%</li>
                <li>Processing Time: 2.3 seconds</li>
                <li>Data Quality: High</li>
              </ul>
            </div>
          </div>
          <div className="mt-4 p-4 bg-green-50 rounded border border-green-200">
            <p className="text-sm text-green-900">
              <strong>Ready for ML Analysis:</strong> Data has been standardized and is now available for fraud detection and compliance monitoring models.
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
