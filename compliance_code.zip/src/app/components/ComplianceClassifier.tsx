import { useState } from 'react';
import { CheckCircle, XCircle, AlertTriangle, TrendingUp } from 'lucide-react';

interface TaxFiling {
  id: string;
  taxpayerId: string;
  filingDate: string;
  income: number;
  deductions: number;
  taxPaid: number;
  status: 'pending' | 'compliant' | 'non-compliant';
  confidence: number;
}

const mockFilings: TaxFiling[] = [
  { id: 'TF-2024-001', taxpayerId: 'TP-10234', filingDate: '2024-03-15', income: 125000, deductions: 15000, taxPaid: 28000, status: 'compliant', confidence: 0.94 },
  { id: 'TF-2024-002', taxpayerId: 'TP-10891', filingDate: '2024-03-18', income: 89000, deductions: 45000, taxPaid: 8500, status: 'non-compliant', confidence: 0.87 },
  { id: 'TF-2024-003', taxpayerId: 'TP-11456', filingDate: '2024-03-20', income: 156000, deductions: 18000, taxPaid: 35000, status: 'compliant', confidence: 0.91 },
  { id: 'TF-2024-004', taxpayerId: 'TP-10567', filingDate: '2024-03-22', income: 67000, deductions: 32000, taxPaid: 7200, status: 'non-compliant', confidence: 0.82 },
  { id: 'TF-2024-005', taxpayerId: 'TP-12890', filingDate: '2024-03-25', income: 198000, deductions: 22000, taxPaid: 48000, status: 'compliant', confidence: 0.96 },
  { id: 'TF-2024-006', taxpayerId: 'TP-10023', filingDate: '2024-03-28', income: 45000, deductions: 28000, taxPaid: 3400, status: 'pending', confidence: 0.65 },
];

export default function ComplianceClassifier() {
  const [filings, setFilings] = useState(mockFilings);
  const [selectedFiling, setSelectedFiling] = useState<TaxFiling | null>(null);

  const runMLPModel = (filing: TaxFiling) => {
    const deductionRatio = filing.deductions / filing.income;
    const taxRatio = filing.taxPaid / filing.income;

    let status: 'compliant' | 'non-compliant';
    let confidence: number;

    if (deductionRatio > 0.4 || taxRatio < 0.1) {
      status = 'non-compliant';
      confidence = 0.75 + Math.random() * 0.2;
    } else {
      status = 'compliant';
      confidence = 0.85 + Math.random() * 0.15;
    }

    return { status, confidence };
  };

  const handleClassify = (filing: TaxFiling) => {
    const result = runMLPModel(filing);
    const updatedFilings = filings.map(f =>
      f.id === filing.id ? { ...f, ...result } : f
    );
    setFilings(updatedFilings);
  };

  const stats = {
    total: filings.length,
    compliant: filings.filter(f => f.status === 'compliant').length,
    nonCompliant: filings.filter(f => f.status === 'non-compliant').length,
    pending: filings.filter(f => f.status === 'pending').length,
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl mb-2">AI-Driven Compliance Monitoring</h2>
        <p className="text-gray-600">Multi-Layer Perceptron model for automatic tax filing classification</p>
      </div>

      <div className="grid grid-cols-4 gap-4">
        <div className="bg-white p-6 rounded-lg border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Total Filings</p>
              <p className="text-3xl mt-1">{stats.total}</p>
            </div>
            <TrendingUp className="w-8 h-8 text-blue-500" />
          </div>
        </div>
        <div className="bg-white p-6 rounded-lg border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Compliant</p>
              <p className="text-3xl mt-1">{stats.compliant}</p>
            </div>
            <CheckCircle className="w-8 h-8 text-green-500" />
          </div>
        </div>
        <div className="bg-white p-6 rounded-lg border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Non-Compliant</p>
              <p className="text-3xl mt-1">{stats.nonCompliant}</p>
            </div>
            <XCircle className="w-8 h-8 text-red-500" />
          </div>
        </div>
        <div className="bg-white p-6 rounded-lg border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Pending Review</p>
              <p className="text-3xl mt-1">{stats.pending}</p>
            </div>
            <AlertTriangle className="w-8 h-8 text-yellow-500" />
          </div>
        </div>
      </div>

      <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="px-6 py-3 text-left text-xs text-gray-600">Filing ID</th>
                <th className="px-6 py-3 text-left text-xs text-gray-600">Taxpayer ID</th>
                <th className="px-6 py-3 text-left text-xs text-gray-600">Income</th>
                <th className="px-6 py-3 text-left text-xs text-gray-600">Deductions</th>
                <th className="px-6 py-3 text-left text-xs text-gray-600">Tax Paid</th>
                <th className="px-6 py-3 text-left text-xs text-gray-600">Status</th>
                <th className="px-6 py-3 text-left text-xs text-gray-600">Confidence</th>
                <th className="px-6 py-3 text-left text-xs text-gray-600">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {filings.map((filing) => (
                <tr key={filing.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 text-sm">{filing.id}</td>
                  <td className="px-6 py-4 text-sm">{filing.taxpayerId}</td>
                  <td className="px-6 py-4 text-sm">${filing.income.toLocaleString()}</td>
                  <td className="px-6 py-4 text-sm">${filing.deductions.toLocaleString()}</td>
                  <td className="px-6 py-4 text-sm">${filing.taxPaid.toLocaleString()}</td>
                  <td className="px-6 py-4">
                    {filing.status === 'compliant' && (
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs bg-green-100 text-green-800">
                        <CheckCircle className="w-3 h-3 mr-1" />
                        Compliant
                      </span>
                    )}
                    {filing.status === 'non-compliant' && (
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs bg-red-100 text-red-800">
                        <XCircle className="w-3 h-3 mr-1" />
                        Non-Compliant
                      </span>
                    )}
                    {filing.status === 'pending' && (
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs bg-yellow-100 text-yellow-800">
                        <AlertTriangle className="w-3 h-3 mr-1" />
                        Pending
                      </span>
                    )}
                  </td>
                  <td className="px-6 py-4 text-sm">
                    {filing.status !== 'pending' ? `${(filing.confidence * 100).toFixed(1)}%` : '-'}
                  </td>
                  <td className="px-6 py-4">
                    {filing.status === 'pending' ? (
                      <button
                        onClick={() => handleClassify(filing)}
                        className="px-3 py-1 bg-blue-500 text-white text-sm rounded hover:bg-blue-600"
                      >
                        Classify
                      </button>
                    ) : (
                      <button
                        onClick={() => setSelectedFiling(filing)}
                        className="px-3 py-1 bg-gray-100 text-gray-700 text-sm rounded hover:bg-gray-200"
                      >
                        Details
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {selectedFiling && (
        <div className="bg-white p-6 rounded-lg border border-gray-200">
          <h3 className="text-lg mb-4">MLP Model Analysis - {selectedFiling.id}</h3>
          <div className="grid grid-cols-2 gap-6">
            <div>
              <p className="text-sm text-gray-600 mb-2">Model Input Features</p>
              <ul className="space-y-2 text-sm">
                <li>Income: ${selectedFiling.income.toLocaleString()}</li>
                <li>Deductions: ${selectedFiling.deductions.toLocaleString()}</li>
                <li>Deduction Ratio: {((selectedFiling.deductions / selectedFiling.income) * 100).toFixed(1)}%</li>
                <li>Tax Paid: ${selectedFiling.taxPaid.toLocaleString()}</li>
                <li>Tax Ratio: {((selectedFiling.taxPaid / selectedFiling.income) * 100).toFixed(1)}%</li>
              </ul>
            </div>
            <div>
              <p className="text-sm text-gray-600 mb-2">Model Output</p>
              <ul className="space-y-2 text-sm">
                <li>Classification: <strong>{selectedFiling.status}</strong></li>
                <li>Confidence Score: <strong>{(selectedFiling.confidence * 100).toFixed(1)}%</strong></li>
                <li>Model: Multi-Layer Perceptron (3 layers)</li>
                <li>Training Accuracy: 92.4%</li>
              </ul>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
