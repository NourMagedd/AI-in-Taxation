import { useState } from 'react';
import { LayoutDashboard, FileCheck, Shield, Target, Database, BookOpen, Menu, X } from 'lucide-react';
import Dashboard from './components/Dashboard';
import ComplianceClassifier from './components/ComplianceClassifier';
import AnomalyDetector from './components/AnomalyDetector';
import AuditRecommendation from './components/AuditRecommendation';
import DataIntegration from './components/DataIntegration';
import KnowledgeSupport from './components/KnowledgeSupport';

type View = 'dashboard' | 'compliance' | 'anomaly' | 'audit' | 'integration' | 'knowledge';

export default function App() {
  const [currentView, setCurrentView] = useState<View>('dashboard');
  const [sidebarOpen, setSidebarOpen] = useState(true);

  const navigation = [
    { id: 'dashboard', name: 'Dashboard', icon: LayoutDashboard, description: 'System Overview' },
    { id: 'compliance', name: 'Compliance Monitoring', icon: FileCheck, description: 'REQ-1: MLP Classifier' },
    { id: 'anomaly', name: 'Anomaly Detection', icon: Shield, description: 'REQ-2: ANN Fraud Detection' },
    { id: 'audit', name: 'Audit Recommendation', icon: Target, description: 'REQ-3: Gradient Boosting' },
    { id: 'integration', name: 'Data Integration', icon: Database, description: 'REQ-4: RPA + NLP' },
    { id: 'knowledge', name: 'Knowledge Support', icon: BookOpen, description: 'REQ-5: NLP + RAG' },
  ];

  const renderContent = () => {
    switch (currentView) {
      case 'dashboard':
        return <Dashboard />;
      case 'compliance':
        return <ComplianceClassifier />;
      case 'anomaly':
        return <AnomalyDetector />;
      case 'audit':
        return <AuditRecommendation />;
      case 'integration':
        return <DataIntegration />;
      case 'knowledge':
        return <KnowledgeSupport />;
      default:
        return <Dashboard />;
    }
  };

  return (
    <div className="size-full flex bg-gray-50">
      <aside className={`${sidebarOpen ? 'w-80' : 'w-0'} transition-all duration-300 bg-white border-r border-gray-200 overflow-hidden`}>
        <div className="h-full flex flex-col">
          <div className="p-6 border-b border-gray-200">
            <h1 className="text-xl mb-1">AI Tax Compliance</h1>
            <p className="text-sm text-gray-600">Intelligent Monitoring System</p>
          </div>
          <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
            {navigation.map((item) => {
              const Icon = item.icon;
              return (
                <button
                  key={item.id}
                  onClick={() => setCurrentView(item.id as View)}
                  className={`w-full flex items-start gap-3 px-4 py-3 rounded-lg transition-colors ${
                    currentView === item.id
                      ? 'bg-blue-50 text-blue-700'
                      : 'text-gray-700 hover:bg-gray-100'
                  }`}
                >
                  <Icon className={`w-5 h-5 mt-0.5 flex-shrink-0 ${
                    currentView === item.id ? 'text-blue-600' : 'text-gray-500'
                  }`} />
                  <div className="text-left">
                    <p className="text-sm">{item.name}</p>
                    <p className="text-xs text-gray-500 mt-0.5">{item.description}</p>
                  </div>
                </button>
              );
            })}
          </nav>
        </div>
      </aside>

      <main className="flex-1 flex flex-col overflow-hidden">
        <header className="bg-white border-b border-gray-200 px-6 py-4 flex items-center gap-4">
          <button
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="p-2 hover:bg-gray-100 rounded-lg"
          >
            {sidebarOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
          <div>
            <h2 className="text-lg">
              {navigation.find(nav => nav.id === currentView)?.name}
            </h2>
          </div>
        </header>

        <div className="flex-1 overflow-y-auto p-6">
          {renderContent()}
        </div>
      </main>
    </div>
  );
}