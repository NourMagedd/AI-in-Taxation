
  # Prototype User Stories

  This is a code bundle for Prototype User Stories. The original project is available at https://www.figma.com/design/83KTX2wpi5L3GHVKl7067X/Prototype-User-Stories.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  